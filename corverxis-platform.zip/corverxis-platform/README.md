# Corverxis Technologies — NexGen Platform

AI-powered enterprise platform built by Corverxis Technologies Ltd, Accra, Ghana.

## Live Applications

| App | File | Description |
|-----|------|-------------|
| 🏠 Main Site | `index.html` | Corverxis homepage with all products |
| 🧬 NexGenLife | `nexgenlife.html` | Life Sciences AI Platform |
| 💻 NexGen Console | `nexgen-console.html` | Developer workbench |
| 💬 NexChat | `nexchat.html` | Enterprise AI chat |
| 🤖 NexAgent | `nexagent.html` | Multi-agent orchestration |
| ☁️ NexCloud | `nexcloud.html` | AI cloud infrastructure |
| 🧪 NexGen AI | `nexarion-ai.html` | AI playground |
| 🔑 API Keys | `nexgen-api-keys.html` | API key portal |

## Deploy to Vercel

1. Push this repo to GitHub
2. Import at [vercel.com/new](https://vercel.com/new)
3. Add environment variables in Vercel dashboard:

```
ANTHROPIC_API_KEY=sk-ant-...
KV_REST_API_URL=https://...
KV_REST_API_TOKEN=...
RESEND_API_KEY=re_...
```

## API Functions (`/api`)

| Endpoint | File | Purpose |
|----------|------|---------|
| `POST /api/chat` | `chat.js` | Anthropic proxy (keeps key server-side) |
| `POST /api/waitlist` | `waitlist.js` | Waitlist signup → Vercel KV |
| `GET/POST/DELETE /api/documents` | `documents.js` | Document save/load |
| `POST /api/export-pdf` | `export-pdf.js` | PDF generation |

## Built With

- **AI:** Anthropic Claude API (NexGen Ultra)
- **Deploy:** Vercel Edge Functions
- **Storage:** Vercel KV
- **Payments:** Stripe (configure links in nexgenlife.html)
- **Email:** Resend

---
© 2025 Corverxis Technologies Ltd · hello@corverxis.ai · corverxis.ai
