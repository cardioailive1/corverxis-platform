// Vercel Edge Function — NexGen API Proxy
// File: api/chat.js  →  serves POST /api/chat
// Forwards requests to Anthropic, keeps the API key server-side

export const config = { runtime: 'edge' };

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

export default async function handler(req) {
  // Preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: CORS });
  }

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405, headers: { ...CORS, 'Content-Type': 'application/json' },
    });
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: 'Invalid JSON body' }), {
      status: 400, headers: { ...CORS, 'Content-Type': 'application/json' },
    });
  }

  const { apiKey } = body;

  if (!apiKey || !apiKey.startsWith('sk-ant-')) {
    return new Response(JSON.stringify({ error: 'Missing or invalid API key. Include apiKey in the request body.' }), {
      status: 401, headers: { ...CORS, 'Content-Type': 'application/json' },
    });
  }

  // Build the Anthropic request — pass through all supported fields
  const anthropicBody = {
    model:         body.model         || 'claude-sonnet-4-6',
    max_tokens:    body.max_tokens    || 4096,
    messages:      body.messages      || [],
    stream:        body.stream        !== false,
  };

  // Optional fields — only include if provided
  if (body.system)           anthropicBody.system          = body.system;
  if (body.temperature != null) anthropicBody.temperature  = body.temperature;
  if (body.thinking)         anthropicBody.thinking        = body.thinking;
  if (body.tools)            anthropicBody.tools           = body.tools;
  if (body.tool_choice)      anthropicBody.tool_choice     = body.tool_choice;
  if (body.stop_sequences)   anthropicBody.stop_sequences  = body.stop_sequences;
  if (body.top_p != null)    anthropicBody.top_p           = body.top_p;
  if (body.top_k != null)    anthropicBody.top_k           = body.top_k;
  if (body.metadata)         anthropicBody.metadata        = body.metadata;

  // When thinking is enabled, temperature must be 1 and top_p must not be set
  if (anthropicBody.thinking?.type === 'enabled') {
    anthropicBody.temperature = 1;
    delete anthropicBody.top_p;
  }

  let anthropicResp;
  try {
    anthropicResp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify(anthropicBody),
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: 'Failed to reach Anthropic API: ' + err.message }), {
      status: 502, headers: { ...CORS, 'Content-Type': 'application/json' },
    });
  }

  // Stream the response body back directly
  return new Response(anthropicResp.body, {
    status: anthropicResp.status,
    headers: {
      ...CORS,
      'Content-Type': anthropicResp.headers.get('content-type') || 'text/event-stream',
      'Cache-Control': 'no-cache, no-store',
      'X-Accel-Buffering': 'no',
    },
  });
}
